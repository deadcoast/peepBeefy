peepBeefy (v0.0.3)

Goal:
  Show gamers what's actually running and what is hogging CPU / RAM / Disk,
  including "invisible" service-backed processes that don't show in the taskbar.

Quick start (Windows 11):

  1) Install Python 3 (from python.org) if you don't already have it.
  2) Install dependencies once:
       py -m pip install --user psutil rich typer

  3) Start the interactive CLI (zero typing):
       Double-click RUN_peepBeefy.bat

     OR (minimal typing, same folder):
       beefy

Inside peepBeefy:
  - beefy peep all       Quick Scan (recommended)
  - beefy peep io        Disk hogs (stutter risk)
  - beefy peep cpu       CPU hogs
  - beefy peep clutter   Tagged gamer background stacks (RGB/VR/VPN/Overlays)
  - beefy baseline save / beefy baseline diff  to see what started itself.

This version does NOT kill processes.
It focuses on visibility (what's running + what's heavy).
